// Entry point for Base 1 app backend
